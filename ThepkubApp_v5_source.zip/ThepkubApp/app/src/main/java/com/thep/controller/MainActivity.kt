package com.thep.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.io.Closeable
import java.io.OutputStream
import java.net.InetSocketAddress
import java.util.UUID
import java.util.concurrent.Executors

private const val BG = 0xFF0B0F1A.toInt()
private const val CARD = 0xFF151B2B.toInt()
private const val CYAN = 0xFF22D3EE.toInt()
private const val PINK = 0xFFF472B6.toInt()
private const val LIME = 0xFFA3E635.toInt()
private const val RED = 0xFFF43F5E.toInt()
private const val MUTED = 0xFF8892A6.toInt()

/** คันเร่งแนวตั้ง 1 ฝั่ง: ดันขึ้น = เดินหน้า ดันลง = ถอย ปล่อย = เด้งกลับ 0 */
class Stick(c: Context, private val color: Int, private val onChange: (Int) -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var v = 0f
    private val snapshot = floatArrayOf(0f)
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val pad = width * 0.5f
                v = (1f - 2f * ((e.y - pad) / (height - 2 * pad)).coerceIn(0f, 1f))
                if (Math.abs(v) < 0.06f) v = 0f
            }
            else -> v = 0f
        }
        onChange((v * 100).toInt()); invalidate(); return true
    }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = w * 0.5f
        p.style = Paint.Style.FILL; p.color = CARD
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        p.color = 0xFF2A3350.toInt(); p.strokeWidth = 4f
        c.drawLine(w / 2, r, w / 2, h - r, p)
        c.drawLine(w * 0.25f, h / 2, w * 0.75f, h / 2, p)
        val y = r + (1f - (v + 1f) / 2f) * (h - 2 * r)
        p.color = color; p.alpha = 70; c.drawCircle(w / 2, y, r * 0.95f, p)
        p.alpha = 255; c.drawCircle(w / 2, y, r * 0.7f, p)
        p.color = BG; p.textAlign = Paint.Align.CENTER; p.textSize = r * 0.5f
        c.drawText("${(v * 100).toInt()}", w / 2, y + r * 0.18f, p)
    }
}

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private var link: Closeable? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var l = 0
    @Volatile private var r = 0
    private var speed = 70
    private var useWifi = false
    private lateinit var status: TextView
    private lateinit var dot: View
    private lateinit var btn: Button
    private lateinit var chipBt: TextView
    private lateinit var chipWifi: TextView

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, col: Int) = TextView(this).apply {
        text = t; textSize = size; setTextColor(col); gravity = Gravity.CENTER
    }

    private fun pill(bg: Int, fg: Int) = Button(this).apply {
        isAllCaps = false; setTextColor(fg)
        background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(bg) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val stickL = Stick(this, CYAN) { l = it }
        val stickR = Stick(this, PINK) { r = it }

        dot = View(this).apply { background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(RED) } }
        status = tv("ยังไม่เชื่อมต่อ", 14f, MUTED)
        chipBt = tv("Bluetooth", 13f, BG); chipWifi = tv("Wi-Fi", 13f, MUTED)
        for (c in listOf(chipBt, chipWifi)) c.setPadding(dp(14), dp(6), dp(14), dp(6))
        chipBt.setOnClickListener { setMode(false) }
        chipWifi.setOnClickListener { setMode(true) }
        setMode(false)

        btn = pill(CYAN, BG).apply { text = "เชื่อมต่อ"; setOnClickListener { if (out == null) connect() else disconnect() } }
        val stop = pill(RED, Color.WHITE).apply { text = "STOP"; setOnClickListener { send("S") } }
        val tools = pill(CARD, CYAN).apply { text = "⚙ ตั้งค่า"; setOnClickListener { toolsDialog() } }

        val speedLabel = tv("ความเร็ว 70%", 13f, LIME)
        val seek = SeekBar(this).apply {
            max = 100; progress = 70
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) { speed = p.coerceAtLeast(10); speedLabel.text = "ความเร็ว $speed%" }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }

        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(chipBt); addView(chipWifi)
        }
        val statusRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(8) })
            addView(status)
        }
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(tv("THEPKUB 4WD", 20f, Color.WHITE))
            addView(statusRow)
            addView(chips, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
            addView(btn, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
            addView(speedLabel, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
            addView(seek, LinearLayout.LayoutParams(-1, -2))
            addView(LinearLayout(context).apply {
                addView(stop, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
                addView(tools, LinearLayout.LayoutParams(0, dp(46), 1f))
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }

        val root = LinearLayout(this).apply {
            setBackgroundColor(BG); setPadding(dp(16), dp(12), dp(16), dp(12))
            gravity = Gravity.CENTER_VERTICAL
            addView(wrapStick("ล้อซ้าย", CYAN, stickL), LinearLayout.LayoutParams(0, -1, 1f))
            addView(mid, LinearLayout.LayoutParams(0, -1, 1.6f))
            addView(wrapStick("ล้อขวา", PINK, stickR), LinearLayout.LayoutParams(0, -1, 1f))
        }
        setContentView(root)

        ui.post(object : Runnable {   // ส่งคำสั่งขับทุก 100 ms (failsafe บนบอร์ด 600 ms)
            override fun run() {
                if (out != null) send("M,${l * speed / 100},${r * speed / 100}")
                ui.postDelayed(this, 100)
            }
        })
    }

    private fun wrapStick(name: String, col: Int, s: Stick) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        addView(tv(name, 14f, col))
        addView(s, LinearLayout.LayoutParams(dp(90), 0, 1f).apply { topMargin = dp(6) })
    }

    private fun setMode(w: Boolean) {
        useWifi = w
        fun st(t: TextView, on: Boolean) {
            t.setTextColor(if (on) BG else MUTED)
            t.background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(if (on) CYAN else CARD) }
        }
        st(chipBt, !w); st(chipWifi, w)
    }

    private fun setStatus(t: String, ok: Boolean) = ui.post {
        status.text = t
        (dot.background as android.graphics.drawable.GradientDrawable).setColor(if (ok) LIME else RED)
        btn.text = if (ok) "ตัดการเชื่อมต่อ" else "เชื่อมต่อ"
    }

    private fun send(cmd: String) {
        val o = out ?: return
        io.execute { try { o.write((cmd + "\n").toByteArray()); o.flush() } catch (e: Exception) { disconnect() } }
    }

    @SuppressLint("MissingPermission")
    private fun connect() {
        if (!useWifi && Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return
        }
        setStatus("กำลังเชื่อมต่อ…", false)
        io.execute {
            try {
                val closeable: Closeable
                val o: OutputStream
                val inp: java.io.InputStream
                if (useWifi) {
                    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                    val net = cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
                        ?: throw Exception("ยังไม่ได้ต่อ Wi-Fi Thepkub_4WD")
                    val sk = net.socketFactory.createSocket()
                    sk.connect(InetSocketAddress("192.168.4.1", 8888), 4000)
                    sk.tcpNoDelay = true
                    closeable = sk; o = sk.getOutputStream(); inp = sk.getInputStream()
                } else {
                    val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                    val dev = ad.bondedDevices.firstOrNull { it.name == "THEP_4WD" }
                        ?: throw Exception("ยังไม่ได้ pair กับ THEP_4WD ในตั้งค่าบลูทูธ")
                    val sk = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                    ad.cancelDiscovery(); sk.connect()
                    closeable = sk; o = sk.outputStream; inp = sk.inputStream
                }
                link = closeable; out = o
                setStatus("เชื่อมต่อแล้ว", true)
                Thread {   // อ่านสถานะจากบอร์ด (FS = failsafe)
                    try {
                        val rd = inp.bufferedReader()
                        while (true) {
                            val ln = rd.readLine() ?: break
                            if (ln.trim() == "FS") setStatus("Failsafe: หยุดอัตโนมัติ", true)
                            else if (ln.startsWith("T,")) setStatus("เชื่อมต่อแล้ว", true)
                        }
                    } catch (_: Exception) {}
                    disconnect()
                }.start()
            } catch (e: Exception) { setStatus(e.message ?: "เชื่อมต่อไม่สำเร็จ", false) }
        }
    }

    private fun disconnect() {
        try { out?.write("S\n".toByteArray()) } catch (_: Exception) {}
        out = null
        try { link?.close() } catch (_: Exception) {}
        link = null
        setStatus("ยังไม่เชื่อมต่อ", false)
    }

    private fun toolsDialog() {
        val names = arrayOf("0 ซ้ายหน้า", "1 ซ้ายหลัง", "2 ขวาหน้า", "3 ขวาหลัง")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        box.addView(tv("ทดสอบมอเตอร์ทีละล้อ (ยกรถลอยก่อน)", 13f, Color.DKGRAY))
        names.forEachIndexed { i, n ->
            box.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(Button(context).apply { text = "ทดสอบ $n"; setOnClickListener { send("T,$i") } }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(Switch(context).apply {
                    text = "กลับทิศ"
                    setOnCheckedChangeListener { _, b -> send("V,$i,${if (b) 1 else 0}") }
                })
            })
        }
        box.addView(Switch(this).apply { text = "สลับซ้าย/ขวา"; setOnCheckedChangeListener { _, b -> send("V,4,${if (b) 1 else 0}") } })
        box.addView(Button(this).apply { text = "โปรไฟล์ขา 0 (Fritzing)"; setOnClickListener { send("P,0") } })
        box.addView(Button(this).apply { text = "โปรไฟล์ขา 1 (ผังเดิม)"; setOnClickListener { send("P,1") } })
        AlertDialog.Builder(this).setTitle("ตั้งค่า / ทดสอบ").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("ปิด", null).show()
    }

    override fun onPause() { super.onPause(); l = 0; r = 0; send("S") }
    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, g: IntArray) { if (g.firstOrNull() == 0) connect() }
}
